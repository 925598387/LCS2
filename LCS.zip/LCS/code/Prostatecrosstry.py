import argparse
from asyncore import write
from decimal import ConversionSyntax
import logging
from multiprocessing import reduction
import os
import random
import shutil
import sys
import time
import pdb
import cv2
import matplotlib.pyplot as plt
import imageio

import numpy as np
import torch
import torch.backends.cudnn as cudnn
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from tensorboardX import SummaryWriter
from torch.utils.data import DataLoader
from torch.nn.modules.loss import CrossEntropyLoss
from torchvision import transforms
from tqdm import tqdm
from skimage.measure import label
from networks.vision_transformer import SwinUnet as ViT_seg
from dataloaders.dataset import (BaseDataSets, RandomGenerator, TwoStreamBatchSampler, ThreeStreamBatchSampler)
from networks.net_factory import BCP_net, net_factory
from utils import losses, ramps, feature_memory, contrastive_losses, val_2d
from config import get_config

parser = argparse.ArgumentParser()
parser.add_argument('--root_path', type=str, default=r'D:\1406lyh\代码\半监督\BCP-main（伪标签）\data_split\Prostate', help='Name of Experiment')  # 用于指定实验的根路径
parser.add_argument('--exp', type=str, default='cross_Prostate10',
                    help='experiment_name')  # 添加一个名为--exp的参数，这是一个字符串类型的参数，默认值为BCP，用于指定实验的名称
parser.add_argument('--model', type=str, default='unet', help='model_name')  # 默认值为unet，用于指定模型的名称。
parser.add_argument('--pre_iterations', type=int, default=10000,
                    help='maximum epoch number to train')  # 默认值为10000，用于指定预训练迭代的最大数量
parser.add_argument('--max_iterations', type=int, default=30000,
                    help='maximum epoch number to train')  # 默认值为30000，用于指定最大迭代次数（最大训练轮数）
parser.add_argument('--batch_size', type=int, default=24,
                    help='batch_size per gpu')  # 添加一个名为--batch_size的参数，这是一个整数类型的参数，默认值为12，用于指定每个GPU的批量大小。
parser.add_argument('--deterministic', type=int, default=1,
                    help='whether use deterministic training')  # 添加一个名为--deterministic的参数，这是一个整数类型的参数，默认值为1，用于指定是否使用确定性训练。
parser.add_argument('--base_lr', type=float, default=0.01,
                    help='segmentation network learning rate')  # 默认值为0.01，用于指定分割网络的学习率。
parser.add_argument('--patch_size', type=list, default=[224, 224],
                    help='patch size of network input')  # 默认值为[256, 256]，用于指定网络输入的裁剪大小。
parser.add_argument('--seed', type=int, default=1337, help='random seed')  # 默认值为1337，用于指定随机种子。
parser.add_argument('--num_classes', type=int, default=2, help='output channel of network')  # 默认值为4，用于指定网络的输出通道数（类别数量）
# label and unlabel
parser.add_argument('--labeled_bs', type=int, default=12,
                    help='labeled_batch_size per gpu')  # 默认值为6，用于指定每个GPU的标记数据的批量大小
parser.add_argument('--labelnum', type=int, default=4, help='labeled data')  # 默认值为7，用于指定标记数据的数量。
parser.add_argument('--u_weight', type=float, default=0.5, help='weight of unlabeled pixels')  # 默认值为0.5，用于指定未标记像素的权重
# costs
parser.add_argument('--gpu', type=str, default='0', help='GPU to use')  # 默认值为'0'，用于指定要使用的GPU。
parser.add_argument('--consistency', type=float, default=0.1, help='consistency')  # 这是一个浮点数类型的参数，默认值为0.1，用于指定一致性。
parser.add_argument('--consistency_rampup', type=float, default=200.0,
                    help='consistency_rampup')  # 添加一个名为--consistency_rampup的参数，这是一个浮点数类型的参数，默认值为200.0，用于指定一致性的斜坡上升值。
parser.add_argument('--magnitude', type=float, default='6.0', help='magnitude')  # 默认值为'6.0'，用于指定幅度。
parser.add_argument('--s_param', type=int, default=6, help='multinum of random masks')  # 默认值为6，用于指定随机掩码的参数。

parser.add_argument('--zip', action='store_true',
                    help='use zipped dataset instead of folder dataset')#表示是否使用压缩数据集而不是文件夹数据集。该参数为一个布尔类型，如果在命令行中使用了该选项，则为True，否则为False，
parser.add_argument('--cache-mode', type=str, default='part', choices=['no', 'full', 'part'],
                    help='no: no cache, '
                    'full: cache all data, '
                    'part: sharding the dataset into nonoverlapping pieces and only cache one piece')#添加一个名为--cache-mode的命令行参数，表示数据集的缓存模式，默认为'part'，可选值为'no'、'full'和'part'，
parser.add_argument('--resume', help='resume from checkpoint')#表示从检查点中恢复训练。该参数为一个字符串类型，表示检查点文件的路径，
parser.add_argument('--accumulation-steps', type=int,
                    help="gradient accumulation steps")#表示梯度累积的步数。该参数为一个整数类型，
parser.add_argument('--use-checkpoint', action='store_true',
                    help="whether to use gradient checkpointing to save memory")#表示是否使用梯度检查点来节省内存。该参数为一个布尔类型，如果在命令行中使用了该选项，则为True，否则为False，
parser.add_argument('--amp-opt-level', type=str, default='O1', choices=['O0', 'O1', 'O2'],
                    help='mixed precision opt level, if O0, no amp is used')#表示混合精度优化级别，默认为'O1'，可选值为'O0'、'O1'和'O2'，
parser.add_argument('--tag', help='tag of experiment')#表示实验的标签。该参数为一个字符串类型，用于标识实验，
parser.add_argument('--eval', action='store_true',
                    help='Perform evaluation only')#表示是否只进行评估。该参数为一个布尔类型，如果在命令行中使用了该选项，则为True，否则为False，
parser.add_argument('--throughput', action='store_true',
                    help='Test throughput only')#表示是否只测试吞吐量。该参数为一个布尔类型，如果在命令行中使用了该选项，则为True，否则为False
parser.add_argument(
    '--cfg', type=str, default="../code/configs/swin_tiny_patch4_window7_224_lite.yaml", help='path to config file', )
parser.add_argument(
    "--opts",
    help="Modify config options by adding 'KEY VALUE' pairs. ",
    default=None,
    nargs='+',
)#允许用户通过添加'KEY VALUE'对来修改配置选项，默认为None，可以提供多个键值对

args = parser.parse_args()
config = get_config(args)
dice_loss = losses.DiceLoss(n_classes=2)  # 创建一个Dice损失函数的实例，n_classes参数设置为4，用于多类别分割任务


def load_net(net, path):  # 这段代码的功能是将从指定路径加载的模型参数应用到预定义的神经网络 net 中，以便恢复或使用已经训练好的模型
    state = torch.load(str(path))  # 将加载的模型和状态信息存储在名为 state 的变量中。
    net.load_state_dict(state['net'])  # 这行代码用于将加载的模型参数加载到预定义的神经网络 net 中


def load_net_opt(net, optimizer, path):  # 用于加载保存在文件中的模型参数和状态信息。它将文件路径 path 转换为字符串并加载对应的模型
    state = torch.load(str(path))  # 将加载的模型和状态信息存储在名为 state 的变量中。
    net.load_state_dict(state['net'])  # 将加载的模型参数应用到预定义的神经网络 net 中。
    optimizer.load_state_dict(state['opt'])  # 将加载的优化器状态应用到预定义的优化器 optimizer 中


def save_net_opt(net, optimizer, path):
    state = {
        'net': net.state_dict(),
        'opt': optimizer.state_dict(),
    }  # state = {'net':net.state_dict(), 'opt':optimizer.state_dict()} 创建了一个字典对象 state，其中包含了神经网络 net 的状态字典和优化器 optimizer 的状态字典。net.state_dict() 返回神经网络的当前参数状态字典，而 optimizer.state_dict() 返回优化器的当前状态字典。
    torch.save(state, str(path))  # 将字典对象 state 保存到指定路径 path。


def get_ACDC_LargestCC(segmentation):  # 该函数用于获取输入分割图像的每个类别的最大连通组件，并将它们合并为一个分割图像。
    class_list = []  # 创建一个空列表 class_list，用于存储每个类别的最大连通组件
    for i in range(1, 4):  # 循环迭代三次，表示要处理三个类别（假设类别从1到3）
        temp_prob = segmentation == i * torch.ones_like(
            segmentation)  # 将segmentation中属于当前类别 i 的像素值设为1，其余像素值设为0，得到一个临时概率图temp_prob
        temp_prob = temp_prob.detach().cpu().numpy()  # 将temp_prob转换为NumPy数组，以便后续处理。
        labels = label(temp_prob)  #: 使用label函数获取temp_prob中的连通组件，即将相邻的像素标记为同一个标签。
        # -- with 'try'
        assert (labels.max() != 0)  # assume at least 1 CC#断言语句，确保至少有一个连通组件，即labels中的最大标签值不为0。
        largestCC = labels == np.argmax(np.bincount(labels.flat)[
                                        1:]) + 1  # 找到最大连通组件，通过np.bincount统计labels中每个标签值出现的次数，并找到除去背景（标签值为0）后最频繁出现的标签，将其作为最大连通组件的标签。
        class_list.append(largestCC * i)  # 将最大连通组件乘以当前类别 i 的值，并添加到class_list中。
    acdc_largestCC = class_list[0] + class_list[1] + class_list[2]  # 将三个类别的最大连通组件相加，得到合并后的最大连通组件图像。
    return torch.from_numpy(acdc_largestCC).cuda()  # 将最大连通组件转换为PyTorch张量，并将其移动到GPU上（假设存在GPU）后返回。


def get_ACDC_2DLargestCC(segmentation):  # 该函数用于获取每个batch中输入分割图像的每个类别的最大连通组件，并将它们合并为一个batch的分割图像。
    batch_list = []  # 创建一个空列表 batch_list，用于存储每个batch的最大连通组件。
    N = segmentation.shape[0]  # 获取输入segmentation的batch大小。
    for i in range(0, N):  # 遍历每个batch中的图像
        class_list = []  # 创建一个空列表 class_list，用于存储每个类别的最大连通组件。
        for c in range(1, 4):  # 遍历三个类别（假设类别从1到3）。
            temp_seg = segmentation[i]  # == c *  torch.ones_like(segmentation[i])#从当前batch中提取当前图像的分割结果
            temp_prob = torch.zeros_like(temp_seg)  # 创建一个与temp_seg相同大小的全零张量temp_prob。
            temp_prob[temp_seg == c] = 1  # 将temp_seg中属于当前类别 c 的像素值设为1，其余像素值保持为0，得到一个临时概率图temp_prob。
            temp_prob = temp_prob.detach().cpu().numpy()  # 转换为NumPy数组，以便后续处理。
            labels = label(temp_prob)  # 使用label函数获取temp_prob中的连通组件，即将相邻的像素标记为同一个标签。
            if labels.max() != 0:  # 检查是否至少有一个连通组件，即labels中的最大标签值不为0。
                largestCC = labels == np.argmax(np.bincount(labels.flat)[
                                                1:]) + 1  # 找到最大连通组件，通过np.bincount统计labels中每个标签值出现的次数，并找到除去背景（标签值为0）后最频繁出现的标签，将其作为最大连通组件的标签。
                class_list.append(largestCC * c)  # 将最大连通组件乘以当前类别 c 的值，并添加到class_list中。
            else:
                class_list.append(temp_prob)  # 如果没有连通组件（背景类别），将temp_prob添加到class_list中。

        n_batch = class_list[0] + class_list[1] + class_list[
            2]  # class_list[0] + class_list[1] + class_list[2]: 将三个类别的最大连通组件相加，得到合并后的最大连通组件图像。
        batch_list.append(n_batch)  # 将合并后的最大连通组件图像添加到batch_list中

    return torch.Tensor(batch_list).cuda()  # 将batch_list转换为PyTorch张量，并将其移动到GPU上（假设存在GPU）后返回。


def get_ACDC_masks(output, nms=0):  # 该函数用于从输出概率图中获取ACDC任务的分割掩码。
    probs = F.softmax(output, dim=1)  # 使用softmax函数对输出概率图进行规范化，将其转换为预测的类别概率。
    _, probs = torch.max(probs, dim=1)  # 从规范化的概率图中获取最可能的类别作为预测的分割掩码。
    if nms == 1:  # 如果nms参数为1，则执行下面的操作。
        probs = get_ACDC_2DLargestCC(
            probs)  # 调用之前定义的get_ACDC_2DLargestCC函数来获取每个batch中输入分割图像的每个类别的最大连通组件，并将它们合并为一个batch的分割掩码。
    return probs  # 返回获取的分割掩码


def get_current_consistency_weight(epoch):  # 该函数用于获取当前的一致性权重，在半监督学习中，一致性权重逐渐增加，是训练中的一个超参数。
    # Consistency ramp-up from https://arxiv.org/abs/1610.02242
    return 5 * args.consistency * ramps.sigmoid_rampup(epoch,
                                                       args.consistency_rampup)  # 根据当前训练的epoch计算一致性权重。args.consistency是之前定义的参数，表示一致性的初始权重，args.consistency_rampup是另一个参数，表示一致性权重的增加速率。


def update_model_ema(model, ema_model,
                     alpha):  # 该函数用于更新指数移动平均模型EMA（Exponential Moving Average Model），用于在训练过程中维护模型参数的平均值。
    model_state = model.state_dict()  # 获取训练模型的参数状态字典
    model_ema_state = ema_model.state_dict()  # 获取EMA模型的参数状态字典
    new_dict = {}  #: 创建一个空字典new_dict，用于存储更新后的EMA模型参数。
    for key in model_state:  # 遍历训练模型的参数。
        new_dict[key] = alpha * model_ema_state[key] + (1 - alpha) * model_state[
            key]  # 使用指数移动平均方法更新EMA模型的参数，alpha是平均值的权重。
    ema_model.load_state_dict(new_dict)  # 将更新后的EMA模型参数加载到EMA模型中，实现参数的平均更新。


def generate_mask(img):  # 该函数生成一个用于图像遮挡的掩码。
    batch_size, channel, img_x, img_y = img.shape[0], img.shape[1], img.shape[2], img.shape[3]  # 获取输入图像img的维度信息。
    loss_mask = torch.ones(batch_size, img_x, img_y).cuda()  # 创建一个与输入图像相同大小的全1张量loss_mask，用于标记不需要进行遮挡的区域。
    mask = torch.ones(img_x, img_y).cuda()  # 创建一个与输入图像大小相同的全1张量mask，用于生成遮挡掩码。
    patch_x, patch_y = int(img_x * 1 / 2), int(img_y * 1 / 2)  # 计算遮挡区域的大小为输入图像的2/3。
    w = np.random.randint(0, img_x - patch_x)  # 随机生成遮挡区域的起始横坐标。
    h = np.random.randint(0, img_y - patch_y)  # 随机生成遮挡区域的起始纵坐标。
    mask[w:w + patch_x, h:h + patch_y] = 0  # 将遮挡区域设置为0，即对应位置被遮挡。
    loss_mask[:, w:w + patch_x, h:h + patch_y] = 0  # 在loss_mask中标记对应的遮挡区域。
    return mask.long(), loss_mask.long()  # 返回生成的遮挡掩码mask和标记不需要遮挡区域的loss_mask。


def random_mask(img, shrink_param=3):  # 该函数生成一个具有随机分割的遮挡掩码。
    batch_size, channel, img_x, img_y = img.shape[0], img.shape[1], img.shape[2], img.shape[3]  # 获取输入图像img的维度信息。
    loss_mask = torch.ones(batch_size, img_x, img_y).cuda()  # 创建一个与输入图像相同大小的全1张量loss_mask，用于标记不需要进行遮挡的区域。
    x_split, y_split = int(img_x / shrink_param), int(img_y / shrink_param)  # 计算图像在x和y方向上的均匀分割大小。
    patch_x, patch_y = int(img_x * 2 / (3 * shrink_param)), int(img_y * 2 / (3 * shrink_param))  # 计算遮挡区域的大小为输入图像的2/3乘以
    mask = torch.ones(img_x, img_y).cuda()  # 创建一个与输入图像大小相同的全1张量mask，用于生成遮挡掩码。
    for x_s in range(shrink_param):  # 循环遍历x方向上的分割数量。
        for y_s in range(shrink_param):  # 循环遍历y方向上的分割数量。
            w = np.random.randint(x_s * x_split, (x_s + 1) * x_split - patch_x)  # 随机生成遮挡区域的起始横坐标，限定在当前x方向的分割范围内。
            h = np.random.randint(y_s * y_split, (y_s + 1) * y_split - patch_y)  # 随机生成遮挡区域的起始纵坐标，限定在当前y方向的分割范围内。
            mask[w:w + patch_x, h:h + patch_y] = 0  # 将遮挡区域设置为0，即对应位置被遮挡。
            loss_mask[:, w:w + patch_x, h:h + patch_y] = 0  # 在loss_mask中标记对应的遮挡区域。
    return mask.long(), loss_mask.long()  # 返回生成的遮挡掩码mask和标记不需要遮挡区域的loss_mask。


def contact_mask(img):  # 该函数生成一个具有遮挡顶部区域的掩码
    batch_size, channel, img_x, img_y = img.shape[0], img.shape[1], img.shape[2], img.shape[3]  # 获取输入图像img的维度信息
    loss_mask = torch.ones(batch_size, img_x, img_y).cuda()  # 创建一个与输入图像相同大小的全1张量loss_mask，用于标记不需要进行遮挡的区域。
    mask = torch.ones(img_x, img_y).cuda()  # 创建一个与输入图像大小相同的全1张量mask，用于生成遮挡掩码。
    patch_y = int(img_y * 4 / 9)  # 计算遮挡顶部区域的大小为输入图像高度的4/9
    h = np.random.randint(0, img_y - patch_y)  # 随机生成遮挡区域的起始纵坐标，限定在输入图像高度的范围内。
    mask[h:h + patch_y, :] = 0  # 将遮挡顶部区域设置为0，即对应位置被遮挡
    loss_mask[:, h:h + patch_y, :] = 0  # 在loss_mask中标记对应的遮挡区域。
    return mask.long(), loss_mask.long()  # 返回生成的遮挡掩码mask和标记不需要遮挡区域的loss_mask。

def generate_mask1(lab):  # 该函数生成一个用于图像遮挡的掩码。
    batch_size, lab_x, lab_y = lab.shape[0], lab.shape[1], lab.shape[2]  # 获取输入图像img的维度信息。
    loss_mask = torch.ones(batch_size, lab_x, lab_y).cuda()  # 创建一个与输入图像相同大小的全1张量loss_mask，用于标记不需要进行遮挡的区域。
    mask = torch.ones(lab_x, lab_y).cuda()  # 创建一个与输入图像大小相同的全1张量mask，用于生成遮挡掩码。
    nonzero_indices = torch.nonzero(lab)
    if nonzero_indices.size()[0] != 0:
        top_left = torch.min(nonzero_indices, dim=0)[0]
        bottom_right = torch.max(nonzero_indices, dim=0)[0]
        # 打印结果
        # print("非零区域的左上坐标:", top_left.tolist())
        # print("非零区域的右下坐标:", bottom_right.tolist())
        x1, y1 = top_left[1], top_left[2]
        x2, y2 = bottom_right[1], bottom_right[2]
        w = x2 - x1
        h = y2 - y1
        # print(x1, y1, x2, y2)
        if w <= 112:
            if h <= 112:
                wd = int((112- w) / 2)
                # print('wd:', wd)
                hd = int((112 - h) / 2)
                # print('hd:', hd)
                x_1, x_2, y_1, y_2 = x1 - wd, x1 - wd + 112, y1 - hd, y1 - hd + 112
                if x_1 <0:
                    x_1 ,x_2 = 0, 112
                if y_1 <0:
                    y_1 ,y_2 = 0, 112

                mask[x_1:x_2, y_1:y_2] = 0
                loss_mask[:, x_1:x_2, y_1:y_2] = 0
                # print(x_1, y_1, x_2, y_2)
            else:
                mask[x1:x1 + 112, y1:y1 + 112] = 0  # 将遮挡区域设置为0，即对应位置被遮挡。
                loss_mask[:, x1:x1 + 112, y1:y1 + 112] = 0
                x_1, x_2, y_1, y_2 = x1, x1 + 112, y1, y1 + 112
        else:
            mask[x1:x1 + 112, y1:y1 + 112] = 0  # 将遮挡区域设置为0，即对应位置被遮挡。
            loss_mask[:, x1:x1 + 112, y1:y1 + 112] = 0
            x_1, x_2, y_1, y_2 = x1, x1 + 112, y1, y1 + 112
            '''mask[x1:x1+w , y1:y1+h] = 0
            loss_mask[:, x1:x1+w , y1:y1+h] = 0
            x_1, x_2, y_1, y_2 = x1, x2, y1, y2'''
    else:
        patch_x, patch_y = int(lab_x *1 / 2), int(lab_y * 1/ 2)  # 计算遮挡区域的大小为输入图像的2/3
        w = np.random.randint(0, lab_x - patch_x)  # 随机生成遮挡区域的起始横坐标。
        h = np.random.randint(0, lab_y - patch_y)  # 随机生成遮挡区域的起始纵坐标。
        mask[w:w + patch_x, h:h + patch_y] = 0  # 将遮挡区域设置为0，即对应位置被遮挡。
        loss_mask[:, w:w + patch_x, h:h + patch_y] = 0  # 在loss_mask中标记对应的遮挡区域。
        x_1 = np.random.randint(0, lab_x - patch_x)
        y_1 = np.random.randint(0, lab_y - patch_y)
        x_2 = x_1+112
        y_2 = y_1+112

    return mask.long(), loss_mask.long(), x_1, y_1, x_2, y_2


def change_mask(img_a, img_b, lab_a, lab_b):
    a_mask, a_loss_mask, xa1, ya1, xa2, ya2 = generate_mask1(lab_a)
    b_mask, b_loss_mask, xb1, yb1, xb2, yb2 = generate_mask1(lab_b)
    if xa2 <= 224 and ya2 <=224 and xb2 <=224 and yb2 <=224:
        a_region = img_a[:, :, xa1:xa2, ya1:ya2].clone()

        b_region = img_b[:, :, xb1:xb2, yb1:yb2].clone()

        la_region = lab_a[:, xa1:xa2, ya1:ya2].clone()
        lb_region = lab_b[:, xb1:xb2, yb1:yb2].clone()

        img_a[:, :, xa1:xa2, ya1:ya2] = b_region

        img_b[:, :, xb1:xb2, yb1:yb2] = a_region
        lab_a[:, xa1:xa2, ya1:ya2] = lb_region
        lab_b[:, xb1:xb2, yb1:yb2] = la_region

    else:
        img_a = img_a
        img_b = img_b
        lab_a = lab_a
        lab_b = lab_b

    return img_a, img_b, lab_a, lab_b




def diceloss(output, img_l):
    CE = nn.CrossEntropyLoss(reduction='mean')
    img_l = img_l.type(torch.int64)
    output_soft = F.softmax(output, dim=1)
    loss_dice = dice_loss(output_soft, img_l.unsqueeze(1))
    loss_ce = CE(output, img_l)
    return loss_dice, loss_ce

def mix_loss(output, img_l, patch_l, mask, l_weight=1.0, u_weight=0.5,
             unlab=False):  # 该函数计算混合损失，结合交叉熵损失（CrossEntropyLoss）和Dice损失（DiceLoss）
    CE = nn.CrossEntropyLoss(reduction='none')  # 创建一个交叉熵损失函数的实例CE，其中reduction='none'表示不对每个样本的损失值进行平均或求和，保留每个像素点的损失值。
    img_l, patch_l = img_l.type(torch.int64), patch_l.type(torch.int64)  # 将img_l和patch_l转换为torch.int64类型，用于计算交叉熵损失。
    output_soft = F.softmax(output, dim=1)  # 对输出概率图进行softmax操作，将其转换为类别概率。
    image_weight, patch_weight = l_weight, u_weight  # 设置图像和patch的权重，l_weight表示图像的权重，u_weight表示patch的权重
    if unlab:  # 如果unlab参数为True，表示使用无标签数据，执行下面的操作
        image_weight, patch_weight = u_weight, l_weight  # 交换图像和patch的权重，用于无标签数据情况下。
    patch_mask = 1 - mask  # 计算patch掩码，即与原始mask取补集
    loss_dice = dice_loss(output_soft, img_l.unsqueeze(1), mask.unsqueeze(1)) * image_weight  # 计算图像的Dice损失，并乘以图像权重。
    # print('dice1:', loss_dice)
    loss_dice += dice_loss(output_soft, patch_l.unsqueeze(1),
                           patch_mask.unsqueeze(1)) * patch_weight  # 计算patch的Dice损失，并乘以patch权重。
    # print('dice2:', loss_dice)
    loss_ce = image_weight * (CE(output, img_l) * mask).sum() / (
                mask.sum() + 1e-16)  # 计算图像的交叉熵损失，乘以图像权重，并在mask区域内取损失值的平均。
    # print('ce1:', loss_ce)
    loss_ce += patch_weight * (CE(output, patch_l) * patch_mask).sum() / (
                patch_mask.sum() + 1e-16)  # loss = loss_ce#计算patch的交叉熵损失，乘以patch权重，并在patch_mask区域内取损失值的平均
    # print('ce2:', loss_ce)
    return loss_dice, loss_ce  # 返回计算得到的Dice损失和交叉熵损失。


def patients_to_slices(dataset, patiens_num):  # 该函数根据数据集名称和患者编号，返回对应患者的切片数。
    ref_dict = None  # 创建一个空的参考字典ref_dict，用于存储数据集对应的患者切片数。
    if "ACDC" in dataset:
        ref_dict = {"1": 32, "3": 68, "7": 136,
                    "14": 256, "21": 396, "28": 512, "35": 664,
                    "70": 1312}  # 根据数据集"ACDC"，创建一个字典ref_dict，其中包含不同患者编号对应的切片数。
    elif "Prostate":
        ref_dict = {"2": 47, "4": 111, "7": 191,
                    "11": 306, "14": 391, "18": 478, "35": 940}

    else:
        print("Error")
    return ref_dict[
        str(patiens_num)]  # 根据给定的患者编号，返回对应的切片数。在字典ref_dict中，患者编号是字符串类型，因此需要将输入的patiens_num转换为字符串类型，以便在字典中查找。


def pre_train(args, snapshot_path):
    base_lr = args.base_lr
    num_classes = args.num_classes
    max_iterations = args.max_iterations
    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu  # 设置环境变量CUDA_VISIBLE_DEVICES，指定可用的GPU设备。
    pre_trained_model = os.path.join(pre_snapshot_path, '{}_best_model.pth'.format(
        args.model))  # 构建预训练模型的路径，其中pre_snapshot_path是之前未展示的变量，这里假设其已经被正确设置。
    labeled_sub_bs, unlabeled_sub_bs = int(args.labeled_bs / 2), int(
        (args.batch_size - args.labeled_bs) / 2)  # 计算标记数据子批量和无标记数据子批量的大小，用于后续数据加载。

    model1 = BCP_net(in_chns=1,
                    class_num=num_classes)
    model2 = ViT_seg(config, img_size=args.patch_size,
                     num_classes=args.num_classes).cuda()  # 创建一个BCP_net模型，其中in_chns=1表示输入通道数为1，class_num=num_classes表示输出类别数为num_classes。
    model2.load_from(config)
    def worker_init_fn(worker_id):
        random.seed(args.seed + worker_id)  # 定义了一个用于数据加载器的worker_init_fn函数，用于初始化每个数据加载器的随机种子。

    db_train = BaseDataSets(base_dir=args.root_path,
                            split="train",
                            num=None,
                            transform=transforms.Compose([RandomGenerator(
                                args.patch_size)]))  # 创建训练数据集db_train，其中base_dir=args.root_path表示数据集的根路径，split="train"表示使用训练数据集，num=None表示使用所有数据，transform=transforms.Compose([RandomGenerator(args.patch_size)])表示应用数据增强方法RandomGenerator来对数据进行随机裁剪，并使用args.patch_size来设置裁剪尺寸。
    db_val = BaseDataSets(base_dir=args.root_path,
                          split="val")  # 创建验证数据集db_val，其中base_dir=args.root_path表示数据集的根路径，split="val"表示使用验证数据集。
    total_slices = len(db_train)  # 获取训练数据集中的总切片数。
    labeled_slice = patients_to_slices(args.root_path, args.labelnum)  # 调用之前定义的patients_to_slices函数，获取标记数据的切片数。
    print("Total slices is: {}, labeled slices is:{}".format(total_slices, labeled_slice))  # 打印总切片数和标记切片数。
    labeled_idxs = list(range(0, labeled_slice))  # 创建一个包含标记数据索引的列表labeled_idxs。
    unlabeled_idxs = list(range(labeled_slice, total_slices))  # 创建一个包含无标记数据索引的列表unlabeled_idxs。
    batch_sampler = TwoStreamBatchSampler(labeled_idxs, unlabeled_idxs, args.batch_size,
                                          args.batch_size - args.labeled_bs)  # 创建一个自定义的批量采样器batch_sampler，用于组合标记数据和无标记数据的批次。

    trainloader = DataLoader(db_train, batch_sampler=batch_sampler, num_workers=0, pin_memory=True,
                             worker_init_fn=worker_init_fn)  # 创建训练数据加载器trainloader，其中batch_sampler指定了批量采样器，num_workers=0表示使用单个进程加载数据，pin_memory=True表示将数据存储在固定内存中，worker_init_fn=worker_init_fn用于设置数据加载器的随机种子。

    valloader = DataLoader(db_val, batch_size=1, shuffle=False,
                           num_workers=0)  # 创建验证数据加载器valloader，其中batch_size=1表示每次加载一个样本，shuffle=False表示不对数据进行随机排序，num_workers=0表示使用单个进程加载数据。

    optimizer1 = optim.SGD(model1.parameters(), lr=base_lr, momentum=0.9,
                           weight_decay=0.0001)
    optimizer2 = optim.SGD(model2.parameters(), lr=base_lr, momentum=0.9,
                          weight_decay=0.0001)  # 创建SGD优化器optimizer，用于优化模型的参数，其中学习率为base_lr，动量为0.9，权重衰减为0.0001

    writer = SummaryWriter(
        snapshot_path + '/log')  # 创建一个用于TensorBoard可视化的SummaryWriter，将日志保存在snapshot_path + '/log'路径下。
    logging.info("Start pre_training")  # 输出日志信息，表示开始预训练。
    logging.info("{} iterations per epoch".format(len(trainloader)))  # 输出日志信息，表示每个epoch有多少次迭代。

    model1.train()
    model2.train()  # 设置模型为训练模式，启用Dropout和BatchNormalization等训练时才会使用的操作。

    iter_num = 0  # 初始化迭代次数为0
    max_epoch = max_iterations // len(
        trainloader) + 1  # 计算最大迭代的epoch数，通过将max_iterations（最大迭代次数）除以每个epoch的迭代次数len(trainloader)得到，再加1来处理不整除的情况。
    best_performance1 = 0.0  # 初始化最佳性能指标best_performance为0.0
    best_performance2 = 0.0
    best_hd = 100  # 初始化最佳Hausdorff距离（Hausdorff distance）为100，Hausdorff距离是用于评估二进制图像分割结果的指标，初始值设为较大的值。
    iterator = tqdm(range(max_epoch), ncols=70)  # 创建一个迭代器iterator，通过tqdm函数展示迭代进度条，ncols=70用于设置进度条的宽度为70。
    for _ in iterator:  # 对每个epoch进行迭代。
        for _, sampled_batch in enumerate(trainloader):  # 对训练数据加载器trainloader中的每个批次进行迭代。
            volume_batch, label_batch = sampled_batch['image'], sampled_batch[
                'label']  # 从采样的批次中获取输入图像数据volume_batch和标签数据label_batch。
            volume_batch, label_batch = volume_batch.cuda(), label_batch.cuda()  # 将输入图像数据volume_batch和标签数据label_batch移到GPU上，以便在GPU上进行计算。

            img_a, img_b = volume_batch[:labeled_sub_bs], volume_batch[
                                                          labeled_sub_bs:args.labeled_bs]  # 将输入图像数据划分为有标记的图像数据img_a和无标记的图像数据img_b，其大小分别为labeled_sub_bs和args.labeled_bs之间。
            lab_a, lab_b = label_batch[:labeled_sub_bs], label_batch[
                                                         labeled_sub_bs:args.labeled_bs]  # 将标签数据划分为有标记的标签数据lab_a和无标记的标签数据lab_b，其大小分别为labeled_sub_bs和args.labeled_bs之间。
            '''img_mask, loss_mask = generate_mask(img_a)  # 调用generate_mask函数生成图像遮挡的掩码img_mask和损失遮挡的掩码loss_mask
            gt_mixl = lab_a * img_mask + lab_b * (
                        1 - img_mask)  # 生成混合标签gt_mixl，通过将有标记的标签lab_a和无标记的标签lab_b按照图像遮挡掩码img_mask进行混合。

            # -- original
            net_input = img_a * img_mask + img_b * (
                        1 - img_mask)  # 生成混合输入图像net_input，通过将有标记的图像img_a和无标记的图像img_b按照图像遮挡掩码img_mask进行混合。'''

            img_maska, loss_maska, _, _, _, _ = generate_mask1(
                lab_a)  # 调用generate_mask函数生成图像遮挡的掩码img_mask和损失遮挡的掩码loss_mask
            img_maskb, loss_maskb, _, _, _, _ = generate_mask1(lab_b)
            cimg_a, cimg_b, clab_a, clab_b = change_mask(img_a, img_b, lab_a, lab_b)

            net_input = torch.cat((cimg_a, img_a, cimg_b, img_b), dim=0)

            gt_mixl = torch.cat((clab_a, clab_b), dim=0)

            out_mixl1 = model1(net_input)

            loss_dicea1c, loss_cea1c = diceloss(out_mixl1[0:6],
                                                clab_a)  # 调用mix_loss函数计算混合损失，其中使用模型输出out_mixl、有标记的标签lab_a、无标记的标签lab_b、损失遮挡掩码loss_mask，设置无标记数据权重为1.0，同时指定使用无标记数据。

            loss_dicea2c, loss_cea2c = diceloss(out_mixl1[6:12], clab_a)

            loss_diceb1c, loss_ceb1c = diceloss(out_mixl1[12:18], clab_b)
            loss_diceb2c, loss_ceb2c = diceloss(out_mixl1[18:24], lab_b)

            loss_dicec = (loss_dicea1c + loss_diceb1c) * 0.5 + loss_dicea2c + loss_diceb2c
            loss_cec = (loss_cea1c + loss_ceb1c) * 0.5 + loss_cea2c + loss_ceb2c

            loss1 = (loss_dicec + loss_cec) / 2

            out_mixl2 = model2(net_input)  # 使用混合输入图像net_input作为模型的输入，获取模型的输出out_mixl。

            loss_dicea1t, loss_cea1t = diceloss(out_mixl2[0:6],
                                                clab_a)  # 调用mix_loss函数计算混合损失，其中使用模型输出out_mixl、有标记的标签lab_a、无标记的标签lab_b、损失遮挡掩码loss_mask，设置无标记数据权重为1.0，同时指定使用无标记数据。

            loss_dicea2t, loss_cea2t = diceloss(out_mixl2[6:12], lab_a)

            loss_diceb1t, loss_ceb1t = diceloss(out_mixl2[12:18],
                                                clab_b)
            loss_diceb2t, loss_ceb2t = diceloss(out_mixl2[18:24], lab_b)

            loss_dicet = (loss_dicea1t + loss_diceb1t) * 0.5 + loss_dicea2t + loss_diceb2t
            loss_cet = (loss_cea1t + loss_ceb1t) * 0.5 + loss_cea2t + loss_ceb2t

            '''loss_dice, loss_ce = mix_loss(out_mixl, lab_a, lab_b, loss_mask, u_weight=1.0,
                                          unlab=True)  # 调用mix_loss函数计算混合损失，其中使用模型输出out_mixl、有标记的标签lab_a、无标记的标签lab_b、损失遮挡掩码loss_mask，设置无标记数据权重为1.0，同时指定使用无标记数据。'''

            loss2 = (loss_dicet + loss_cet) / 2  # 计算总损失loss，将Dice损失和交叉熵损失的平均作为总损失。

            optimizer1.zero_grad()
            optimizer2.zero_grad()  # 清零优化器的梯度缓存
            loss1.backward()
            loss2.backward()  # 对损失进行反向传播，计算参数的梯度
            optimizer1.step()
            optimizer2.step()  # 根据计算得到的梯度，更新模型的参数。

            iter_num += 1  # 迭代次数加1。

            writer.add_scalar('info/total_loss1', loss1, iter_num)
            writer.add_scalar('info/total_loss2', loss2, iter_num)  # 将总损失loss写入TensorBoard的日志中。
            writer.add_scalar('info/mix_dicec', loss_dicec, iter_num)
            writer.add_scalar('info/mix_dicet', loss_dicet, iter_num)  # 将Dice损失loss_dice写入TensorBoard的日志中。
            writer.add_scalar('info/mix_cec', loss_cec, iter_num)
            writer.add_scalar('info/mix_cet', loss_cet, iter_num)  # 将交叉熵损失loss_ce写入TensorBoard的日志中。

            logging.info('iteration %d: loss1: %f, mix_dicec: %f, mix_cec: %f' % (
                iter_num, loss1, loss_dicec, loss_cec))
            logging.info('iteration %d: loss2: %f, mix_dicet: %f, mix_cet: %f' % (
            iter_num, loss2, loss_dicet, loss_cet))  # 输出当前迭代的日志信息，包含迭代次数、总损失、Dice损失和交叉熵损失。

            if iter_num % 20 == 0:  # 如果当前迭代次数iter_num是20的倍数，执行以下代码块。
                image = net_input[1, 0:1, :, :]  # 获取混合输入图像net_input中的第2个样本（索引为1），并提取其第一个通道的图像数据，作为可视化的输入图像。
                writer.add_image('pre_train/Mixed_Image', image, iter_num)  # 将输入图像image写入TensorBoard的日志中，用于可视化。
                outputs1 = torch.argmax(torch.softmax(out_mixl1, dim=1), dim=1,
                                       keepdim=True)  # 对混合模型输出out_mixl进行softmax操作，并计算出每个像素点的最可能类别。
                outputs2 = torch.argmax(torch.softmax(out_mixl2, dim=1), dim=1,
                                       keepdim=True)  # 对混合模型输出out_mixl进行softmax操作，并计算出每个像素点的最可能类别。
                writer.add_image('pre_train/Mixed_Prediction1', outputs1[1, ...] * 50,
                                 iter_num)  # 将预测结果outputs[1, ...]写入TensorBoard的日志中，通过乘以50来放大预测结果，用于可视化。
                writer.add_image('pre_train/Mixed_Prediction2', outputs2[1, ...] * 50,
                                 iter_num)  # 将预测结果outputs[1, ...]写入TensorBoard的日志中，通过乘以50来放大预测结果，用于可视化。
                labs = gt_mixl[1, ...].unsqueeze(0) * 50  # 获取混合标签gt_mixl中的第2个样本（索引为1），并将其在第0维上增加一个维度，然后乘以50，用于可视化。
                writer.add_image('pre_train/Mixed_GroundTruth', labs, iter_num)  # 将混合标签labs写入TensorBoard的日志中，用于可视化。

            if iter_num > 0 and iter_num % 200 == 0:  # 如果当前迭代次数iter_num大于0且是200的倍数，执行以下代码块。
                model1.eval()
                model2.eval()  # 将模型设置为评估模式，禁用Dropout和BatchNormalization等训练时才会使用的操作。
                metric_list1 = 0.0
                metric_list2 = 0.0  # 初始化指标列表metric_list为0.0，用于存储各个类别的评估指标。
                for _, sampled_batch in enumerate(valloader):  # 对验证数据加载器valloader中的每个批次进行迭代。
                    metric_i = val_2d.test_single_volume(sampled_batch["image"], sampled_batch["label"], model1,
                                                         classes=num_classes)  #: 调用val_2d.test_single_volume函数对单个样本进行评估，得到评估指标metric_i。
                    metric_list1 += np.array(metric_i)  # 将评估指标metric_i转换为NumPy数组，并累加到指标列表metric_list中。
                metric_list1 = metric_list1 / len(db_val)  # 将指标列表metric_list除以验证集数据的数量，得到各个类别的平均评估指标。
                for _, sampled_batch in enumerate(valloader):  # 对验证数据加载器valloader中的每个批次进行迭代。
                    metric_i = val_2d.test_single_volume(sampled_batch["image"], sampled_batch["label"], model2,
                                                         classes=num_classes)  #: 调用val_2d.test_single_volume函数对单个样本进行评估，得到评估指标metric_i。
                    metric_list2 += np.array(metric_i)  # 将评估指标metric_i转换为NumPy数组，并累加到指标列表metric_list中。
                metric_list2 = metric_list2 / len(db_val)  # 将指标列表metric_list除以验证集数据的数量，得到各个类别的平均评估指标。
                for class_i in range(num_classes - 1):  # 对每个类别（除去背景类别）进行迭代。
                    writer.add_scalar('info/val1_{}_dice'.format(class_i + 1), metric_list1[class_i, 0],
                                      iter_num)  # 将第class_i+1类的Dice指标写入TensorBoard的日志中。
                    writer.add_scalar('info/val1_{}_hd95'.format(class_i + 1), metric_list1[class_i, 1],
                                      iter_num)  # 将第class_i+1类的Hausdorff距离指标写入TensorBoard的日志中。

                performance1 = np.mean(metric_list1, axis=0)[0]  # 计算所有类别的平均Dice指标，作为性能指标performance。

                for class_i in range(num_classes - 1):  # 对每个类别（除去背景类别）进行迭代。
                    writer.add_scalar('info/val2_{}_dice'.format(class_i + 1), metric_list2[class_i, 0],
                                      iter_num)  # 将第class_i+1类的Dice指标写入TensorBoard的日志中。
                    writer.add_scalar('info/val2_{}_hd95'.format(class_i + 1), metric_list2[class_i, 1],
                                      iter_num)  # 将第class_i+1类的Hausdorff距离指标写入TensorBoard的日志中。

                performance2 = np.mean(metric_list2, axis=0)[0]  # 计算所有类别的平均Dice指标，作为性能指标performance。
                writer.add_scalar('info/val1_mean_dice', performance1, iter_num)
                writer.add_scalar('info/va2l_mean_dice', performance2, iter_num)  # 将平均Dice指标performance写入TensorBoard的日志中。

                if performance1 > best_performance1:  # 如果当前性能指标performance超过最佳性能指标best_performance，执行以下代码块。
                    best_performance1 = performance1  # 更新最佳性能指标为当前性能指标
                    save_mode_path = os.path.join(snapshot_path, 'iter1_{}_dice_{}.pth'.format(iter_num,
                                                                                              round(best_performance1,
                                                                                                    4)))  # 构建保存模型的路径，包含迭代次数和最佳性能指标。
                    save_best_path = os.path.join(snapshot_path, '{}_best_model1.pth'.format(args.model))  # 构建保存最佳模型的路径。
                    save_net_opt(model1, optimizer1, save_mode_path)  # 保存当前模型及其优化器的状态到指定路径。
                    save_net_opt(model1, optimizer1, save_best_path)  # 保存当前模型及其优化器的状态到最佳模型的路径。

                if performance2 > best_performance2:  # 如果当前性能指标performance超过最佳性能指标best_performance，执行以下代码块。
                    best_performance2 = performance2  # 更新最佳性能指标为当前性能指标
                    save_mode_path = os.path.join(snapshot_path, 'iter2_{}_dice_{}.pth'.format(iter_num,
                                                                                              round(best_performance2,
                                                                                                    4)))  # 构建保存模型的路径，包含迭代次数和最佳性能指标。
                    save_best_path = os.path.join(snapshot_path, '{}_best_model2.pth'.format(args.model))  # 构建保存最佳模型的路径。
                    save_net_opt(model2, optimizer2, save_mode_path)  # 保存当前模型及其优化器的状态到指定路径。
                    save_net_opt(model2, optimizer2, save_best_path)  # 保存当前模型及其优化器的状态到最佳模型的路径。

                logging.info('iteration %d : mean_dice1 : %f' % (iter_num, performance1))  # 输出当前迭代的日志信息，包含迭代次数和平均Dice指标。
                model1.train()
                logging.info('iteration %d : mean_dice2 : %f' % (iter_num, performance2))  # 输出当前迭代的日志信息，包含迭代次数和平均Dice指标。
                model2.train()  # 将模型重新设置为训练模式，启用Dropout和BatchNormalization等训练时才会使用的操作。

            if iter_num >= max_iterations:
                break  # 如果当前迭代次数iter_num超过或等于最大迭代次数max_iterations，跳出迭代。
        if iter_num >= max_iterations:
            iterator.close()
            break  # 如果当前迭代次数iter_num超过或等于最大迭代次数max_iterations，关闭进度条迭代器iterator并跳出外层迭代。
    writer.close()  # 关闭TensorBoard的SummaryWriter


def self_train(args, pre_snapshot_path, snapshot_path):
    base_lr = args.base_lr  # 获取学习率的基准值base_lr
    num_classes = args.num_classes
    max_iterations = args.max_iterations
    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu
    pre_trained_model1 = os.path.join(pre_snapshot_path, '{}_best_model1.pth'.format(args.model))  # 构建预训练模型的路径。
    pre_trained_model2 = os.path.join(pre_snapshot_path, '{}_best_model2.pth'.format(args.model))
    labeled_sub_bs, unlabeled_sub_bs = int(args.labeled_bs / 2), int(
        (args.batch_size - args.labeled_bs) / 2)  # 计算有标记子批次大小labeled_sub_bs和无标记子批次大小unlabeled_sub_bs

    model1 = BCP_net(in_chns=1,
                    class_num=num_classes)  # 创建未经过EMA（Exponential Moving Average）的模型model，传入输入通道数为1和类别数量num_classes。
    ema_model1 = BCP_net(in_chns=1, class_num=num_classes,
                        ema=True)  # 创建经过EMA的模型ema_model，传入输入通道数为1、类别数量num_classes和ema=True表示启用EMA。

    model2 = ViT_seg(config, img_size=args.patch_size,
                     num_classes=args.num_classes).cuda()

    def create_model(ema=True):#定义一个内部函数create_model，用于创建模型。该函数接受一个布尔类型的参数ema，默认值为False，表示是否创建指数移动平均(EMA)模型。
        # Network definition
        model = ViT_seg(config, img_size=args.patch_size,
                     num_classes=args.num_classes).cuda()#根据参数args.model指定的网络类型，创建一个神经网络模型(model)。in_chns=1表示输入通道数为1，class_num=num_classes表示输出类别数目为num_classes

        if ema:
            for param in model.parameters():
                param.detach_()#对模型的所有参数进行detach_()操作，使其在计算图中断开与原始模型的连接，实现参数的独立更新，从而得到EMA模型。
        return model

    ema_model2 = create_model(ema=True)

    def worker_init_fn(worker_id):  # 定义一个工作线程初始化函数worker_init_fn，用于设置工作线程的随机种子。
        random.seed(args.seed + worker_id)

    db_train = BaseDataSets(base_dir=args.root_path,
                            split="train",
                            num=None,
                            transform=transforms.Compose([RandomGenerator(
                                args.patch_size)]))  # 创建训练数据集db_train，传入数据集根目录args.root_path、划分为训练集、num=None表示使用所有数据、以及数据增强的转换操作
    db_val = BaseDataSets(base_dir=args.root_path, split="val")  # 创建验证数据集db_val，传入数据集根目录args.root_path和划分为验证集。
    total_slices = len(db_train)  # 计算训练数据集的总片段数量total_slices
    labeled_slice = patients_to_slices(args.root_path,
                                       args.labelnum)  # 获取有标记的片段数量labeled_slice，通过调用patients_to_slices函数根据数据集类型（"ACDC"或"Prostate"）和指定的args.labelnum得到。
    print("Total slices is: {}, labeled slices is:{}".format(total_slices, labeled_slice))
    labeled_idxs = list(range(0, labeled_slice))  # 创建包含从0到labeled_slice-1的有标记片段索引列表labeled_idxs。
    unlabeled_idxs = list(
        range(labeled_slice, total_slices))  # 创建包含从labeled_slice到total_slices-1的无标记片段索引列表unlabeled_idxs。
    batch_sampler = TwoStreamBatchSampler(labeled_idxs, unlabeled_idxs, args.batch_size,
                                          args.batch_size - args.labeled_bs)  # 创建一个双流式批次采样器batch_sampler，用于从有标记片段和无标记片段中分别获取批次数据，指定批次大小为args.batch_size，有标记子批次大小为args.labeled_bs。

    trainloader = DataLoader(db_train, batch_sampler=batch_sampler, num_workers=0, pin_memory=True,
                             worker_init_fn=worker_init_fn)  # 创建训练数据加载器trainloader，传入训练数据集db_train和批次采样器batch_sampler，指定使用0个工作线程（num_workers=0）和将数据加载到GPU的锁页内存

    valloader = DataLoader(db_val, batch_size=1, shuffle=False,
                           num_workers=0)  # 创建验证数据加载器valloader，传入验证数据集db_val，指定批次大小为1（每次只加载一个样本）、不进行随机洗牌（shuffle=False）和使用0个工作线程（num_workers=0）。

    optimizer1 = optim.SGD(model1.parameters(), lr=base_lr, momentum=0.9,
                          weight_decay=0.0001)  # 创建随机梯度下降（SGD）优化器，传入模型model的参数、学习率base_lr、动量参数为0.9和权重衰减参数为0.0001
    optimizer2 = optim.SGD(model2.parameters(), lr=base_lr, momentum=0.9,
                           weight_decay=0.0001)  # 创建随机梯度下降（SGD）优化器，传入模型model的参数、学习率base_lr、动量参数为0.9和权重衰减参数为0.0001

    load_net(ema_model1,
             pre_trained_model1)  # load_net(ema_model, pre_trained_model): 载入EMA模型ema_model的权重参数，从预训练模型pre_trained_model加载
    load_net_opt(model1, optimizer1, pre_trained_model1)  # 载入模型model及其优化器optimizer的权重参数，从预训练模型pre_trained_model加载。
    logging.info("Loaded from {}".format(pre_trained_model1))  # 输出日志信息，表示已从预训练模型加载了权重参数。

    load_net(ema_model2,
             pre_trained_model2)  # load_net(ema_model, pre_trained_model): 载入EMA模型ema_model的权重参数，从预训练模型pre_trained_model加载
    load_net_opt(model2, optimizer2, pre_trained_model2)  # 载入模型model及其优化器optimizer的权重参数，从预训练模型pre_trained_model加载。
    logging.info("Loaded from {}".format(pre_trained_model2))  # 输出日志信息，表示已从预训练模型加载了权重参数。

    writer = SummaryWriter(
        snapshot_path + '/log')  # 创建TensorBoard的SummaryWriter，用于记录训练过程中的日志和可视化信息，保存在snapshot_path + '/log'目录下。
    logging.info("Start self_training")  # 输出日志信息，表示开始自训练过程。
    logging.info("{} iterations per epoch".format(len(trainloader)))  # 输出日志信息，表示每个epoch中有多少次迭代。

    model1.train()  # 将未经过EMA的模型model设置为训练模式，启用Dropout和BatchNormalization等训练时才会使用的操作
    ema_model1.train()  # 将经过EMA的模型ema_model设置为训练模式，启用Dropout和BatchNormalization等训练时才会使用的操作。

    model2.train()
    ema_model2.train()

    ce_loss = CrossEntropyLoss()  # 创建交叉熵损失函数ce_loss

    iter_num = 0  # 初始化迭代次数为0
    max_epoch = max_iterations // len(trainloader) + 1  # 计算总的最大训练epoch数，即总迭代次数除以每个epoch的迭代次数，并向上取整。
    best_performance = 0.0  # 初始化最佳性能指标为0.0
    best_hd = 100  # 初始化最佳Hausdorff距离（Hausdorff distance）为100（一个较大的数，确保在训练开始时能够找到更好的性能）。
    iterator = tqdm(range(max_epoch), ncols=70)  # 创建一个tqdm进度条迭代器，用于显示训练进度，ncols=70表示进度条的宽度为70个字符。
    for _ in iterator:  # 对于每个epoch，通过tqdm进度条迭代器进行遍历
        for _, sampled_batch in enumerate(trainloader):  # 对于训练数据加载器中的每个批次，使用enumerate函数获取批次的索引_和采样的批次数据sampled_batch
            volume_batch, label_batch = sampled_batch['image'], sampled_batch[
                'label']  # 从采样的批次数据中获取图像数据volume_batch和标签数据label_batch。
            volume_batch, label_batch = volume_batch.cuda(), label_batch.cuda()  # 将图像数据和标签数据移动到GPU上，以便在GPU上进行计算。

            img_a, img_b = volume_batch[:labeled_sub_bs], volume_batch[
                                                          labeled_sub_bs:args.labeled_bs]  # 将有标记部分的图像数据分成两部分，分别赋值给img_a和img_b。
            uimg_a, uimg_b = volume_batch[args.labeled_bs:args.labeled_bs + unlabeled_sub_bs], volume_batch[
                                                                                               args.labeled_bs + unlabeled_sub_bs:]  # 将无标记部分的图像数据分成两部分，分别赋值给uimg_a和uimg_b。
            ulab_a, ulab_b = label_batch[args.labeled_bs:args.labeled_bs + unlabeled_sub_bs], label_batch[
                                                                                              args.labeled_bs + unlabeled_sub_bs:]  # 将无标记部分的标签数据分成两部分，分别赋值给ulab_a和ulab_b。
            lab_a, lab_b = label_batch[:labeled_sub_bs], label_batch[
                                                         labeled_sub_bs:args.labeled_bs]  # 将有标记部分的标签数据分成两部分，分别赋值给lab_a和lab_b。
            with torch.no_grad():  # 在这个代码块中的操作不会计算梯度。
                pre_a = ema_model1(uimg_a)  # 使用EMA模型ema_model预测无标记部分的图像uimg_a的输出pre_a。
                pre_b = ema_model2(uimg_b)  # 使用EMA模型ema_model预测无标记部分的图像uimg_b的输出pre_b。
                plab_a = get_ACDC_masks(pre_a, nms=1)  # 对预测输出pre_a进行后处理，得到无标记部分的预测标签plab_a，使用get_ACDC_masks函数进行处理。
                plab_b = get_ACDC_masks(pre_b, nms=1)  # 对预测输出pre_b进行后处理，得到无标记部分的预测标签plab_b，使用get_ACDC_masks函数进行处理。
                '''img_mask, loss_mask = generate_mask(
                    img_a)  # 生成有标记部分的图像img_a的掩码img_mask和损失掩码loss_mask，使用generate_mask函数进行处理。
                unl_label = ulab_a * img_mask + lab_a * (
                            1 - img_mask)  # 将无标记部分的标签ulab_a和有标记部分的标签lab_a根据掩码img_mask进行融合，得到无标记部分的标签unl_label。
                l_label = lab_b * img_mask + ulab_b * (
                            1 - img_mask)  # 将有标记部分的标签lab_b和无标记部分的标签ulab_b根据掩码img_mask进行融合，得到有标记部分的标签l_label。'''
                img_mask_a, loss_mask_a, _, _, _, _ = generate_mask1(
                    lab_a)  # 生成有标记部分的图像img_a的掩码img_mask和损失掩码loss_mask，使用generate_mask函数进行处理。
                img_mask_b, loss_mask_b, _, _, _, _ = generate_mask1(lab_b)
                unl_label = ulab_a * img_mask_a + lab_a * (
                        1 - img_mask_a)  # 将无标记部分的标签ulab_a和有标记部分的标签lab_a根据掩码img_mask进行融合，得到无标记部分的标签unl_label。
                l_label = lab_b * img_mask_b + ulab_b * (
                        1 - img_mask_b)  # 将有标记部分的标签lab_b和无标记部分的标签ulab_b根据掩码img_mask进行融合，得到有标记部分的标签l_label。
            aback, apre, aback_l, apre_l = change_mask(img_a, uimg_a, lab_a, plab_a)
            bback, bpre, bback_l, bpre_l = change_mask(img_b, uimg_b, lab_b, plab_b)
            consistency_weight = get_current_consistency_weight(
                iter_num // 150)  # 根据当前迭代次数iter_num除以150，得到当前一致性权重consistency_weight，使用get_current_consistency_weight函数进行处理。

            '''pre_input = torch.cat((apre, bpre), dim=0)
            pre_input_l = torch.cat((apre_l, bpre_l), dim=0)
            back_input = torch.cat((aback, bback), dim=0)
            back_input_l = torch.cat((aback_l, bback_l), dim=0)'''


            cnnout_unl = model1(apre)  # 对无标记部分的输入net_input_unl进行模型预测，得到无标记部分的输出out_unl。
            cnnout_l = model1(bback)  # 对有标记部分的输入net_input_l进行模型预测，得到有标记部分的输出out_l。
            transout_unl = model2(apre)
            transout_l = model2(bback)

            unl_dicec, unl_cec = diceloss(cnnout_unl, apre_l)
            l_dicec, l_cec = diceloss(cnnout_l, bback_l)
            unl_dicet, unl_cet = diceloss(transout_unl, apre_l)
            l_dicet, l_cet = diceloss(transout_l, bback_l)

            loss_ce = (unl_cec + l_cec + unl_cet + l_cet)*0.5  # 计算总的交叉熵损失loss_ce，将无标记部分和有标记部分的交叉熵损失相加。
            loss_dice = unl_dicec + l_dicec + unl_dicet + l_dicet  # 计算总的Dice损失loss_dice，将无标记部分和有标记部分的Dice损失相加。

            cnnout_unl_soft = torch.softmax(cnnout_unl, dim=1)
            cnnout_l_soft = torch.softmax(cnnout_l, dim=1)


            cnnout_unl_plab= get_ACDC_masks(cnnout_unl, nms=1)
            cnnout_l_plab = get_ACDC_masks(cnnout_l, nms=1)
            transout_unl_plab = get_ACDC_masks(transout_unl, nms=1)
            transout_l_plab = get_ACDC_masks(transout_l, nms=1)


            cnnplabdice_unl , cnnplabce_unl = diceloss(
                cnnout_unl, transout_unl_plab)  # 计算模型1对伪标签的一致性损失。
            cnnplabdice_l, cnnplabce_l = diceloss(cnnout_l, transout_l_plab)
            '''tranplabdice_unl, tranplabce_unl = diceloss(transout_unl, cnnout_unl_plab)
            tranplabdice_l, tranplabce_l = diceloss(transout_l, cnnout_l_plab)'''


            '''cross_loss_dice = (cnnplabdice_unl+cnnplabdice_l+tranplabdice_unl+tranplabdice_l)*consistency_weight
            cross_loss_ce = (cnnplabce_unl + cnnplabce_l+ tranplabce_unl+ tranplabce_l)*consistency_weight'''

            cross_loss_dice = (cnnplabdice_unl + cnnplabdice_l ) * consistency_weight
            cross_loss_ce = (cnnplabce_unl + cnnplabce_l ) * consistency_weight

            loss = loss_dice + loss_ce  + cross_loss_dice + cross_loss_ce# 计算总的损失loss，将Dice损失和交叉熵损失的平均值作为总的损失。

            optimizer1.zero_grad()  # 清除优化器的梯度
            optimizer2.zero_grad()
            loss.backward()  # 计算损失相对于模型参数的梯度
            optimizer1.step()
            optimizer2.step()# 更新模型参数

            iter_num += 1  # 增加迭代次数计数。
            update_model_ema(model1, ema_model1, 0.99)  # 使用指数移动平均更新EMA模型的参数，更新率为0.99。
            update_model_ema(model2, ema_model2, 0.99)

            writer.add_scalar('info/total_loss', loss, iter_num)
            writer.add_scalar('info/mix_dice', loss_dice, iter_num)
            writer.add_scalar('info/mix_ce', loss_ce, iter_num)
            writer.add_scalar('info/consistency_weight', consistency_weight,
                              iter_num)  # 对训练过程中的一些信息进行记录和可视化，例如损失、Dice损失、交叉熵损失、一致性权重等，以及每隔一定迭代次数计算在验证集上的性能指标

            logging.info('iteration %d: loss: %f, mix_dice: %f, mix_ce: %f' % (iter_num, loss, loss_dice, loss_ce))

            '''if iter_num % 20 == 0:  # 检查当前迭代次数iter_num是否为20的倍数
                image = net_input_unl[1, 0:1, :, :]  # 从无标记部分的输入net_input_unl中获取第一个样本的灰度图像数据，并且将通道数限制在1通道（灰度图像）
                writer.add_image('train/Un_Image', image,
                                 iter_num)  # 将无标记部分的输入灰度图像image记录为TensorBoard中的图像，路径为'train/Un_Image'，并记录在当前迭代次数iter_num下。
                outputs = torch.argmax(torch.softmax(out_unl, dim=1), dim=1,
                                       keepdim=True)  # 对无标记部分的输出out_unl进行softmax操作，并取得softmax概率最大的类别索引
                writer.add_image('train/Un_Prediction', outputs[1, ...] * 50,
                                 iter_num)  # 将无标记部分的预测结果outputs记录为TensorBoard中的图像，路径为'train/Un_Prediction'，并记录在当前迭代次数iter_num下，同时乘以50，以增加可视化对比度。
                labs = unl_label[1, ...].unsqueeze(
                    0) * 50  # 从无标记部分的标签unl_label中获取第一个样本的标签数据，并将通道数限制在1通道（灰度图像），同时乘以50，以增加可视化对比度。
                writer.add_image('train/Un_GroundTruth', labs,
                                 iter_num)  # 将无标记部分的标签图像labs记录为TensorBoard中的图像，路径为'train/Un_GroundTruth'，并记录在当前迭代次数iter_num下。

                image_l = net_input_l[1, 0:1, :, :]  # 从有标记部分的输入net_input_l中获取第一个样本的灰度图像数据，并将通道数限制在1通道（灰度图像）。
                writer.add_image('train/L_Image', image_l,
                                 iter_num)  # 将有标记部分的输入灰度图像image_l记录为TensorBoard中的图像，路径为'train/L_Image'，并记录在当前迭代次数iter_num下。
                outputs_l = torch.argmax(torch.softmax(out_l, dim=1), dim=1,
                                         keepdim=True)  # 对有标记部分的输出out_l进行softmax操作，并取得softmax概率最大的类别索引。
                writer.add_image('train/L_Prediction', outputs_l[1, ...] * 50,
                                 iter_num)  # 将有标记部分的预测结果outputs_l记录为TensorBoard中的图像，路径为'train/L_Prediction'，并记录在当前迭代次数iter_num下，同时乘以50，以增加可视化对比度。
                labs_l = l_label[1, ...].unsqueeze(
                    0) * 50  # 从有标记部分的标签l_label中获取第一个样本的标签数据，并将通道数限制在1通道（灰度图像），同时乘以50，以增加可视化对比度。
                writer.add_image('train/L_GroundTruth', labs_l,
                                 iter_num)  # 将有标记部分的标签图像labs_l记录为TensorBoard中的图像，路径为'train/L_GroundTruth'，并记录在当前迭代次数iter_num下。'''

            if iter_num > 0 and iter_num % 200 == 0:  ##如果当前迭代次数大于0且为200的倍数。
                model1.eval()  # 将模型设置为评估模式，不计算梯度
                metric_list = 0.0  # 初始化指标列表metric_list为0.0，用于存储各个类别的评估指标。
                for _, sampled_batch in enumerate(valloader):  # 对验证数据加载器valloader中的每个批次进行迭代。
                    metric_i = val_2d.test_single_volume(sampled_batch["image"], sampled_batch["label"], model1,
                                                         classes=num_classes)  #: 调用val_2d.test_single_volume函数对单个样本进行评估，得到评估指标metric_i。
                    metric_list += np.array(metric_i)  # 将评估指标metric_i转换为NumPy数组，并累加到指标列表metric_list中。
                metric_list = metric_list / len(db_val)  # 将指标列表metric_list除以验证集数据的数量，得到各个类别的平均评估指标。
                for class_i in range(num_classes - 1):  ##对每个类别（除去背景类别）进行迭代。
                    writer.add_scalar('info/val_{}_dice'.format(class_i + 1), metric_list[class_i, 0],
                                      iter_num)  # 将第class_i+1类的Dice指标写入TensorBoard的日志中。
                    writer.add_scalar('info/val_{}_hd95'.format(class_i + 1), metric_list[class_i, 1],
                                      iter_num)  # 将第class_i+1类的Hausdorff距离指标写入TensorBoard的日志中。

                performance = np.mean(metric_list, axis=0)[0]  # 计算所有类别的平均Dice指标，作为性能指标performance。
                writer.add_scalar('info/val_mean_dice', performance, iter_num)  # 将平均Dice指标performance写入TensorBoard的日志中。

                if performance > best_performance:  # 如果当前性能指标performance超过最佳性能指标best_performance，执行以下代码块。
                    best_performance = performance  # 更新最佳性能指标为当前性能指标
                    save_mode_path = os.path.join(snapshot_path, 'iter_{}_dice_{}.pth'.format(iter_num,
                                                                                              round(best_performance,
                                                                                                    4)))  # 构建保存模型的路径，包含迭代次数和最佳性能指标。
                    save_best_path = os.path.join(snapshot_path, '{}_best_model.pth'.format(args.model))  # 构建保存最佳模型的路径。
                    torch.save(model1.state_dict(), save_mode_path)  # 保存当前模型及其优化器的状态到指定路径。
                    torch.save(model1.state_dict(), save_best_path)  # 保存当前模型及其优化器的状态到最佳模型的路径。

                logging.info('iteration %d : mean_dice : %f' % (iter_num, performance))  # 输出当前迭代的日志信息，包含迭代次数和平均Dice指标。
                model1.train()

            if iter_num >= max_iterations:
                break
        if iter_num >= max_iterations:
            iterator.close()
            break
    writer.close()


if __name__ == "__main__":  # 检查当前脚本是否作为主程序运行，避免在导入模块时执行下面的代码块。
    if args.deterministic:  # 如果参数args.deterministic为True，则设置PyTorch的随机种子和CUDA的随机种子，以保证实验的可重复性。
        cudnn.benchmark = False
        cudnn.deterministic = True
        random.seed(args.seed)
        np.random.seed(args.seed)
        torch.manual_seed(args.seed)
        torch.cuda.manual_seed(args.seed)

    # -- path to save models
    pre_snapshot_path = "./model/BCP1/ACDC_{}_{}_labeled/pre_train".format(args.exp, args.labelnum)
    self_snapshot_path = "./model/BCP1/ACDC_{}_{}_labeled/self_train".format(args.exp,
                                                                            args.labelnum)  # 定义预训练模型和自训练模型的保存路径pre_snapshot_path和self_snapshot_path，路径中包含了实验名称args.exp和标记数据的数量args.labelnum。
    for snapshot_path in [pre_snapshot_path, self_snapshot_path]:
        if not os.path.exists(snapshot_path):
            os.makedirs(snapshot_path)  # 检查预训练模型和自训练模型的保存路径是否存在，如果不存在，则创建相应的文件夹。
    shutil.copy('../code/ACDC_BCP_train.py', self_snapshot_path)  # 使用shutil.copy函数将ACDC_BCP_train.py文件复制到自训练模型的保存路径下

    # Pre_train
    logging.basicConfig(filename=pre_snapshot_path+"/log.txt", level=logging.INFO, format='[%(asctime)s.%(msecs)03d] %(message)s', datefmt='%H:%M:%S')
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))#配置日志记录，将日志输出保存到pre_snapshot_path路径下的log.txt文件中，并将日志信息同时打印到控制台。
    logging.info(str(args))#使用日志记录器记录实验参数args
    pre_train(args, pre_snapshot_path)#调用pre_train函数进行预训练，传入参数args和预训练模型的保存路径pre_snapshot_path

    # Self_train
    logging.basicConfig(filename=self_snapshot_path + "/log.txt", level=logging.INFO,
                        format='[%(asctime)s.%(msecs)03d] %(message)s', datefmt='%H:%M:%S')
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    logging.info(str(args))
    self_train(args, pre_snapshot_path, self_snapshot_path)




